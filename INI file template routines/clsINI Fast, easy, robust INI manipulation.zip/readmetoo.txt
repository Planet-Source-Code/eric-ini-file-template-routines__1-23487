clsINI Fast, easy, robust INI manipulation 
  
 Print  
  Email  
  
 
 

 Submitted on: 5/16/2001 8:52:47 PM
By: Eric Dalquist
Level: Intermediate
User Rating:      By 1 Users
Compatibility:VB 6.0

Users have accessed this code 388 times.
  (About the author) 
 
  
     
Ever wanted an easy way to store settings for your program? 

The registry is great and all but it's hard to check to make sure things are saved correctly and if you're not sure what you're doing you can clutter it up with junk quickly.

The ini class can be compiled into a stand-alone DLL or included directly into your project. 
It has methods to create, delete and rename, sections, keys and values within a file making storing settings a breeze!

If you have any questions or comments please post them here or email me at ebdalqui@mtu.edu

 
